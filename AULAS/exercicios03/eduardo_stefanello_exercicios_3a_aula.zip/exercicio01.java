//Imprima todos os números de 120 a 280.

class exercicio01{
    public static void main(String[] args) {
        for(int i = 120; i <= 280; i++)
            System.out.println(i);
    }
}
